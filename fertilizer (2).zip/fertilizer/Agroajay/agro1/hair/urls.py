"""
URL configuration for hair project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from app import views
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
    path('admin/', admin.site.urls),

    path('',views.profile),
    path('index.html',views.index),
    path('about.html',views.about),
    path('product.html',views.product),
    path('contact.html',views.contct),
    path('feature.html',views.feature),
    path('how-to-use.html',views.howtouse),
    path('login.html',views.login),
    path('log',views.login1),
    path('buynow',views.buynow),
    path('logout',views.logout),
    path('reg.html',views.register),
    path('reg',views.reg),
    path('index1.html',views.index1),
    path('about1.html',views.about1),
    path('product1.html',views.product1),
    path('contact1.html',views.contact1),
    path('feature1.html',views.feature1),
    path('how-to-use1.html',views.howtouse1),
    path('cart1.html',views.cart),
    path('add',views.addtocart,name='add'),
    path('add1',views.addtocart1,name='add'),
    path('buy', views.buy),
    path('cancel', views.cancel),
    path('buyall',views.buyall),
    path('chckout.html',views.checkout),
    path('hairprdt1.html',views.prdt1),
    path('hairprdt2.html', views.prdt2),
    path('hairprdt3.html', views.prdt3),
    path('hairprdt4.html', views.prdt4),
    path('decrement', views.decrement),
    path('increment', views.increment),
    path('decrement1', views.decrement1),
    path('increment1', views.increment1),
path('order', views.order),
path('addproduct', views.addproduct),
path('newproduct', views.newproduct),
path('order1', views.order1),
path('admin.html', views.admin),
path('adminorder1', views.adminorder1),
path('success', views.success),
path('success1', views.success1),
path('success2', views.success2),
path('order.html', views.orders),
path('orders1.html', views.orders1),
path('cancelorder', views.cancelorder),
path('stock', views.stock),
path('message', views.message),
path('cart1', views.cart1,name='cart1'),
path('inbox', views.inbox,name='inbox'),
path('singleproduct', views.singleproduct),

 # forgot password
    path("forgot",views.forgot_password,name="forgot"),
    path("reset/<token>",views.reset_password,name="reset"),
    path("reset/reset2/<token>",views.reset_password2,name="reset2"),
]
if settings.DEBUG:
    urlpatterns+=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)