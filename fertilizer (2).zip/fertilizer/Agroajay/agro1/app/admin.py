from django.contrib import admin

# Register your models here.
from .models import user
admin.site.register(user)

from .models import logi
admin.site.register(logi)

from .models import prduct
admin.site.register(prduct)

from .models import crt
admin.site.register(crt)

from .models import detail
admin.site.register(detail)

from .models import contact
admin.site.register(contact)

from .models import PasswordReset
admin.site.register(PasswordReset)




