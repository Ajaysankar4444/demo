from django.shortcuts import render,redirect,HttpResponse
from .models import *
from .models import logi,prduct
from django.utils.crypto import get_random_string
from django.core.mail import send_mail
from django.conf import settings
import datetime
from django.contrib import messages
# Create your views here.
def index(re):
    d=prduct.objects.all()
    return render(re,'index.html',{'p':d})
def about(re):
    return render(re,'about.html')
def product(re):
    d = prduct.objects.all()
    return render(re,'product.html',{'p':d})
def contct(re):
    return render(re,'contact.html')
def feature(re):
    return render(re,'feature.html')
def howtouse(re):
    return render(re,'how-to-use.html')
def login(re):
    return render(re,'login.html')
def register(re):
    return render(re,'reg.html')
def reg(request):
    if request.method == 'POST':
        a = user.objects.all()
        x = request.POST['n1']
        s = 'username already exist'
        f=0
        for i in a:
            if i.name == x:
                f +=1
        if f == 0:
            y = request.POST['n2']
            z = request.POST['n3']
            w = request.POST['n4']
            v=request.POST['n5']
            if z == w:
                d =user.objects.create(name=x,emaill=y,phone=v,pswd=z,cpswd=w,status=1)
                d.save()
                d1 =logi.objects.create(name=x, pswd=z,status=1)
                d1.save()
                return render(request, 'login.html')
            else:
                return render(request, 'reg.html', {'a': 'password do not match'})

        else:
            return render(request, 'reg.html', {'r': s})
    else:
        return render(request,'reg.html')

def index1(re):
    d = prduct.objects.all()
    l = []
    d1 = crt.objects.filter(name=re.session['id'], payment='pending')
    for i in d1:
        l.append(i.product)

    return render(re, 'index1.html', {'p': d, 'r': l})
def about1(re):
    return render(re,'about1.html')
def product1(re):
    d = prduct.objects.all()
    l=[]
    d1=crt.objects.filter(name=re.session['id'],payment='pending')
    for i in d1:
        l.append(i.product)

    return render(re,'product1.html',{'p':d,'r':l})
def contact1(re):
    return render(re,'contact1.html')
def feature1(re):
    return render(re,'feature1.html')
def howtouse1(re):
    return render(re,'how-to-use1.html')

def profile(request):
    if 'id' in request.session:
        u=request.session['id']
        d = logi.objects.get(name=u)
        if d.status == 1:
            d1=prduct.objects.all()
            return render(request, 'index1.html',{'p':d1})

        else:

            return render(request,'admin.html' )
    else:
        d = prduct.objects.all()
        return render(request, 'index.html', {'p': d})

def login1(request):
    if request.method == 'POST':
        x = request.POST['n1']
        y = request.POST['n2']
        z = 'incorrect password'
        w = 'user not found'
        try:
            d = logi.objects.get(name=x)
            if d.pswd == y:
                request.session['id'] = x
                if d.status == 1:

                    return redirect(profile)
                elif d.status == 2:
                    return redirect(profile)
            else:
                return render(request, 'login.html',{'r':z})
        except Exception:
            return render(request, 'login.html', {'r': w})

def logout(request):
    if 'id' in request.session:
        request.session.flush()
        return render(request,'index.html')

def cart(request):
    d=crt.objects.filter(name=request.session['id'],payment='pending')
    n=0
    total=0
    for i in d:
        if i.qty != 0:
            n+=1
        total=total+(i.qty*i.prize)
    total+=15
    return render(request,'cart.html',{'r':d,'a':n,'total':total})

def cart1(request):
    if request.method=='POST':
        if request.method=='POST':
            d=crt.objects.filter(name=request.session['id'],product=request.POST['name'],payment='pending')
            d.delete()
            d=prduct.objects.get(product=request.POST['name'],quantity=request.POST['qty'])
            z = datetime.datetime.now().strftime("%Y-%m-%d")
            d1=crt.objects.create(name=request.session['id'],product=request.POST['name'],prize=d.prize,qty=1,image=d.image,payment='pending',delivery='pending',date=z,quantity=request.POST['qty'])
            d1.save()
            d=crt.objects.filter(name=request.session['id'],product=request.POST['name'],payment='pending')
            n=0
            total=0
            for i in d:
                if i.qty != 0:
                    n+=1
                total=total+(i.qty*i.prize)
            total+=15
            return render(request,'cart1.html',{'r':d,'a':n,'total':total})




def addtocart(request):
    if request.method=='POST':
        d=prduct.objects.get(product=request.POST['name'],quantity=500)
        z = datetime.datetime.now().strftime("%Y-%m-%d")
        d1=crt.objects.create(name=request.session['id'],product=request.POST['name'],prize=d.prize,qty=1,image=d.image,payment='pending',delivery='pending',date=z,quantity=500)
        d1.save()

        d = prduct.objects.all()
        l = []
        d1 = crt.objects.filter(name=request.session['id'], payment='pending')
        for i in d1:
            l.append(i.product)

        return render(request, 'product1.html', {'p': d, 'r': l})

def addtocart1(request):
    if request.method=='POST':
        d=prduct.objects.get(product=request.POST['name'])
        z = datetime.datetime.now().strftime("%Y-%m-%d")
        d1=crt.objects.create(name=request.session['id'],product=request.POST['name'],prize=d.prize,qty=1,image=d.image,payment='pending',delivery='pending',date=z)
        d1.save()

        d = prduct.objects.all()
        l = []
        d1 = crt.objects.filter(name=request.session['id'], payment='pending')
        for i in d1:
            l.append(i.product)

        return render(request, 'index1.html', {'p': d, 'r': l})


def buynow(request):
    if request.method == 'POST':
        p=request.POST['product']
        a=request.POST['action']
        if a == 'buy':
            d=crt.objects.filter(name=request.session['id'],payment='pending',product=p)
            d.update(qty=request.POST[p])
            d = crt.objects.filter(name=request.session['id'], payment='pending', product=p)
            n=0
            total=0
            for i in d:
                n=15+(i.qty*i.prize)
                total=(i.qty*i.prize)
            return render(request,'chckout.html',{'r':d,'a':n,'total':total})
        elif a == 'buyall':
            d=crt.objects.filter(name=request.session['id'],payment='pending')
            for i in d:
                d1=crt.objects.filter(product=i.product,name=request.session['id'],payment='pending')
        elif a == 'status':
            if request.method=='POST':
                d=crt.objects.filter(name=request.POST['name'],product=request.POST['product'],qty=request.POST['qtyy'])
                d.update(delivery=request.POST['status'])
                return redirect(orders)
        elif a == 'cancel':
            if request.method=='POST':
                d=crt.objects.filter(name=request.POST['name'],product=request.POST['product'],qty=request.POST['qtyy'],quantity=request.POST['qty'])
                d.update(delivery='cancel')
                return redirect(orders1)
        elif a == 'pay':
            if request.method == 'POST':
                email=request.POST['email']
                n=0

                a=int(request.POST['qtyy'])
                print(a)
                d=prduct.objects.get(product=request.POST['product'],quantity=request.POST['qty'])
                n=n+(d.prize*a)
                m=n+15
                n=(n+15)*100
                print(n)
                send_mail('Refund', f"Your amount rs{m} for product {request.POST['product']} has been refunded",'settings.EMAIL_HOST_USER', [email],fail_silently=False)

                return render(request, 'payment2.html', {'r':n,'s':request.POST['product'],'t':request.POST['name'],'u':request.POST['qtyy']})
        elif a == 'update':
            if request.method == 'POST':
                d=prduct.objects.filter(product=request.POST['product'],quantity=request.POST['qty'])
                d.update(stock=request.POST['stock'])
                return redirect(stock)


def success2(request):
    if request.method == 'POST':
        d=crt.objects.filter(name=request.POST['name'],product=request.POST['product'],qty=request.POST['qtyy'])
        d.delete( )
        return redirect(cancelorder)
def checkout(request):
    return render(request,'chckout.html')

def prdt1(request):
    return render(request,'hairprdt1.html')
def prdt2(request):
    return render(request,'hairprdt2.html')
def prdt3(request):
    return render(request,'hairprdt3.html')
def prdt4(request):
    return render(request,'hairprdt4.html')
def decrement(request):
    d = crt.objects.filter(name=request.session['id'], payment='pending',product=request.POST['product'])
    qy=0
    for i in d:
        qy=i.qty-1
    if qy == 0:
        d.delete()
    else:
        d.update(qty=qy)
    return redirect(cart)
def increment(request):
    d = crt.objects.filter(name=request.session['id'], payment='pending',product=request.POST['product'])
    d1=prduct.objects.get(product=request.POST['product'],quantity=request.POST['qtyy'])
    qy=0
    for i in d:
        qy=i.qty+1

    if qy > d1.stock:
        d2 = crt.objects.filter(name=request.session['id'], payment='pending')
        n = 0
        total = 0

        for i in d2:
            if i.qty != 0:
                n += 1
            total = total + (i.qty * i.prize)
        total += 15
        return render(request, 'cart.html', {'r': d2, 'a': n, 'total': total,'m':f"{request.POST['product']} is out of stock"})
    else:
        d.update(qty=qy)
    return redirect(cart)
def decrement1(request):
    d = crt.objects.filter(name=request.session['id'], payment='pending',product=request.POST['product'])
    qy=0
    for i in d:
        qy=i.qty-1
    if qy == 0:
        d.delete()
    else:
        d.update(qty=qy)
    d=crt.objects.filter(name=request.session['id'],product=request.POST['product'],payment='pending')
    n=0
    total=0
    for i in d:
        if i.qty != 0:
            n+=1
        total=total+(i.qty*i.prize)
    total+=15
    return render(request,'cart1.html',{'r':d,'a':n,'total':total})
def increment1(request):
    d = crt.objects.filter(name=request.session['id'], payment='pending',product=request.POST['product'])
    d1=prduct.objects.get(product=request.POST['product'],quantity=request.POST['qtyy'])
    qy=0

    for i in d:
        qy=i.qty+1

    if qy > d1.stock:
        d2 = crt.objects.filter(name=request.session['id'], payment='pending')
        n = 0
        total = 0

        for i in d2:
            if i.qty != 0:
                n += 1
            total = total + (i.qty * i.prize)
        total += 15
        return render(request, 'cart1.html', {'r': d2, 'a': n, 'total': total,'m':f"{request.POST['product']} is out of stock"})
    else:
        d.update(qty=qy)
    d=crt.objects.filter(name=request.session['id'],product=request.POST['product'],payment='pending')
    n=0
    total=0
    for i in d:
        if i.qty != 0:
            n+=1
        total=total+(i.qty*i.prize)
    total+=15
    return render(request,'cart1.html',{'r':d,'a':n,'total':total})
def buy(request):
    if request.method=='POST':
        try:
            d1=detail.objects.get(session=request.session['id'])
            d2=detail.objects.filter(session=request.session['id'])
            d = crt.objects.filter(name=request.session['id'], payment='pending', product=request.POST['product'])
            n = 0
            total = 0
            for i in d:
                n = 15 + (i.qty * i.prize)
                total = (i.qty * i.prize)
            return render(request, 'chckout.html', {'s':d2,'r': d, 'a': n, 'total': total,'name':d1.name,'email':d1.email,'phone':d1.phone,'pin':d1.pin,'state':d1.state})
        except Exception:
            d = crt.objects.filter(name=request.session['id'], payment='pending', product=request.POST['product'])
            n = 0
            total = 0
            for i in d:
                n = 15 + (i.qty * i.prize)
                total = (i.qty * i.prize)
            return render(request, 'chckout.html', {'r': d, 'a': n, 'total': total})

def cancel(request):
    if request.method == 'POST':
        d = crt.objects.filter(name=request.session['id'], payment='pending', product=request.POST['product'])
        d.delete()
        return redirect(cart)

def buyall(request):
    if request.method=='POST':
        try:
            d1=detail.objects.get(session=request.session['id'])
            d2=detail.objects.filter(session=request.session['id'])
            d = crt.objects.filter(name=request.session['id'], payment='pending')
            n = 0
            total = 0
            for i in d:
                n = n + (i.qty * i.prize)
                total = (i.qty * i.prize)
            n=n+15
            return render(request, 'chckout1.html', {'s':d2,'r': d, 'a': n, 'total': total,'name':d1.name,'email':d1.email,'phone':d1.phone,'pin':d1.pin,'state':d1.state})
        except Exception:
            d = crt.objects.filter(name=request.session['id'], payment='pending')
            n = 0
            total = 0
            for i in d:
                n = n + (i.qty * i.prize)
                total = (i.qty * i.prize)
            n=n+15
            return render(request, 'chckout1.html', {'r': d, 'a': n, 'total': total})

def order(request):
    if request.method=='POST':
        try:
            d = detail.objects.get(session=request.session['id'])
            d=detail.objects.filter(session=request.session['id'])
            d.update(name=request.POST['name'], email=request.POST['email'],phone=request.POST['phone'], adress=request.POST['adress'],session=request.session['id'], pin=request.POST['pin'],state=request.POST['state'])
            d = crt.objects.filter(name=request.session['id'], payment='pending',product=request.POST['product'])
            n = 0
            for i in d:
                n = n + (i.qty * i.prize)
            n = (n + 15) * 100
            return render(request,'payment.html',{'r':n,'s':request.POST['product']})
        except Exception:
            d=detail.objects.create(name=request.POST['name'],email=request.POST['email'],phone=request.POST['phone'],adress=request.POST['adress'],session=request.session['id'],pin=request.POST['pin'],state=request.POST['state'])
            d.save()
            d = crt.objects.filter(name=request.session['id'], payment='pending',product=request.POST['product'])
            n = 0
            for i in d:
                n = n + (i.qty * i.prize)
            n = (n + 15)*100
            return render(request, 'payment.html', {'r': n,'s':request.POST['product']})

def order1(request):
    if request.method=='POST':
        try:
            d=detail.objects.get(session=request.session['id'])
            d=detail.objects.filter(session=request.session['id'])
            d.update(name=request.POST['name'],email=request.POST['email'],phone=request.POST['phone'],adress=request.POST['adress'],session=request.session['id'],pin=request.POST['pin'],state=request.POST['state'])

            d = crt.objects.filter(name=request.session['id'], payment='pending')
            n = 0
            for i in d:
                n = n + (i.qty * i.prize)
            n = (n + 15) * 100
            return render(request,'payment1.html',{'r':n})
        except Exception:
            d=detail.objects.create(name=request.POST['name'],email=request.POST['email'],phone=request.POST['phone'],adress=request.POST['adress'],session=request.session['id'],pin=request.POST['pin'],state=request.POST['state'])
            d.save()
            d = crt.objects.filter(name=request.session['id'], payment='pending')
            n = 0
            for i in d:
                n = n + (i.qty * i.prize)
            n = (n + 15)*100
            return render(request, 'payment1.html', {'r': n})

def admin(re):
    return render(re,'admin.html')
def adminorder1(re):
    if 'id' in re.session:
        d=crt.objecs.filter(payment='complete')

    return render(re,'admin.html')

def success(re):
    if 'id' in re.session:
        if re.method == 'POST':
            n=0
            d=crt.objects.filter(payment='pending',product=re.POST['p'],name=re.session['id'])
            z = datetime.datetime.now().strftime("%Y-%m-%d")
            d1=prduct.objects.filter(product=re.POST['p'])
            for i in d:
                n=i.qty
            for i in d1:
                n=i.stock-n
            
            d1.update(stock=n)

            d.update(payment='complete',date=z)
            return render(re,'success.html')

def success1(re):
    if 'id' in re.session:
        if re.method == 'POST':
            d=crt.objects.filter(payment='pending',name=re.session['id'])
            z = datetime.datetime.now().strftime("%Y-%m-%d")
            n = 0
            for i in d:
                d1=prduct.objects.filter(product=i.product)
                n=i.qty
                print(n)
                for j in d1:
                    print(j.stock)
                    n=j.stock-n
                    break
                d1.update(stock=n)
                

            print(n)
            d.update(payment='complete',date=z)
            return render(re,'success.html')

def orders(request):
    d=crt.objects.filter(payment='complete')
    d1=detail.objects.all()
    return render(request,'orders.html',{'r':d,'s':d1})

def orders1(request):
    d=crt.objects.filter(payment='complete',name=request.session['id'])
    d1=detail.objects.filter(session=request.session['id'])
    return render(request,'orders1.html',{'r':d,'s':d1})

def cancelorder(request):
    d=crt.objects.filter(delivery='cancel')
    d1=detail.objects.all()
    return render(request,'cancel.html',{'r':d,'s':d1})
def stock(request):
    d=prduct.objects.all()
    return render(request,'stock.html',{'r':d})
def message(request):
    if request.method == 'POST':
        d=contact.objects.create(name=request.POST['name'],email=request.POST['email'],subject=request.POST['subject'],message=request.POST['message'])
        d.save()
        return render(request,'contact1.html',{'r':'message sent'})
def inbox(request):
    d=contact.objects.all()
    return render(request,'inbox.html',{'r':d})

def addproduct(request):
    return render(request,'addproduct.html')

def newproduct(request):
    if request.method == 'POST':
        d=prduct.objects.create(quantity=request.POST['quantity'],qty=0,product=request.POST['product'],prize=request.POST['prize'],image=request.FILES['image'],stock=request.POST['stock'])
        d.save()
        return render(request,'addproduct.html',{'r':'product added succesfully'})

# ------------------- PASSWORD FUNCTIONS STARTS ---------------------


def forgot_password(request):
    if request.method == 'POST':
        email = request.POST['email']
        try:
            userr = user.objects.get(emaill=email)
            usr=logi.objects.get(name=userr.name)
        except:
            messages.info(request,"Email id not registered")
            return redirect(forgot_password)
        # Generate and save a unique token
        token = get_random_string(length=4)
        PasswordReset.objects.create(user=userr, token=token)

        # Send email with reset link
        reset_link = f'http://127.0.0.1:8000/reset/{token}'
        try:
            send_mail('Reset Your Password', f'Click the link to reset your password: {reset_link}','settings.EMAIL_HOST_USER', [email],fail_silently=False)
            return render(request, 'emailsent.html')
        except:
            messages.info(request,"Network connection failed")
            return redirect(forgot_password)

    return render(request, 'password_reset_sent.html')

# def resetpage(r,token):
#     return render(r, 'reset_password.html')

def reset_password(request, token):
    # Verify token and reset the password
    password_reset = PasswordReset.objects.get(token=token)
    usr = user.objects.get(id=password_reset.user_id)
    return render(request, 'reset_password.html',{'token':token})

def reset_password2(request, token):
    # Verify token and reset the password
    print(token)
    password_reset = PasswordReset.objects.get(token=token)
    usr = user.objects.get(id=password_reset.user_id)
    d=logi.objects.filter(name=usr.name)
    if request.method == 'POST':
        new_password = request.POST.get('newpassword')
        repeat_password = request.POST.get('repeatpassword')
        if repeat_password == new_password:
            password_reset.user.pswd = new_password
            password_reset.user.save()
            d.update(pswd=new_password)
            password_reset.delete()
            return redirect(login)
    return render(request, 'reset_password.html')

# ------------------- PASSWORD FUNCTIONS ENDS ---------------------

def singleproduct(request):
    if request.method == 'POST':
        d=prduct.objects.filter(product=request.POST['name'])
        return render(request,'singleproduct.html',{'p':d})