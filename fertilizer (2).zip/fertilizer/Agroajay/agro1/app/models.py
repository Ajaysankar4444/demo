from django.db import models

# Create your models here.
class user(models.Model):
    name=models.CharField(max_length=50)
    emaill=models.EmailField()
    phone=models.IntegerField()
    pswd=models.CharField(max_length=20)
    cpswd=models.CharField(max_length=20)
    status=models.IntegerField()
    def __str__(self):
        return self.name

class logi(models.Model):
    name = models.CharField(max_length=50)
    pswd = models.CharField(max_length=20)
    status = models.IntegerField()
    def __str__(self):
        return self.name

class prduct(models.Model):
    product=models.CharField(max_length=50)
    prize=models.IntegerField()
    image=models.FileField()
    qty = models.IntegerField()
    stock=models.IntegerField()
    quantity=models.IntegerField()
    def __str__(self):
        return self.product

class crt(models.Model):
    name=models.CharField(max_length=50)
    product=models.CharField(max_length=50)
    prize=models.IntegerField()
    image=models.FileField()
    qty=models.IntegerField()
    payment=models.CharField(max_length=50)
    delivery=models.CharField(max_length=50)
    date=models.DateField()
    quantity=models.IntegerField()
    def __str__(self):
        return self.name

class detail(models.Model):
    name=models.CharField(max_length=50)
    email=models.EmailField()
    phone=models.IntegerField()
    pin=models.CharField(max_length=20)
    state=models.CharField(max_length=20)

    adress=models.CharField(max_length=500)
    session=models.CharField(max_length=50)
    def __str__(self):
        return self.name

class contact(models.Model):
    name=models.CharField(max_length=50)
    email=models.EmailField()
    subject=models.CharField(max_length=500)
    message=models.CharField(max_length=500)
    def __str__(self):
        return self.name

class PasswordReset(models.Model):
    user = models.ForeignKey(user, on_delete=models.CASCADE)
    token = models.CharField(max_length=100, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)